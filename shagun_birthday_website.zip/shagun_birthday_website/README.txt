SHAGUN BIRTHDAY WEBSITE

Login:
  Username: Shagun (case-insensitive)
  Password: huihui

Unlock:
  The countdown ends at 12:00 AM India time (Asia/Kolkata) on 4 December 2026.
  The Continue button remains disabled until then, then opens the birthday page.

Personalise:
- Replace the sample letter in index.html with your own words.
- Add photographs through the photo frames after the birthday page unlocks.
- Select a romantic audio file from the music section and press Play.

Important:
This is a front-end surprise gate, not secure authentication. The username and password are visible in the page source and can be bypassed by someone with technical knowledge. Do not use it to protect private or sensitive information. For a true private login, use server-side authentication.
Photos and audio are selected locally in the visitor's browser and are not uploaded to a server.

Publish with GitHub Pages:
1. Create a repository.
2. Upload index.html.
3. Go to Settings > Pages.
4. Select Deploy from a branch, choose main and /(root), then Save.
